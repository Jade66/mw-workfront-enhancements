var taskBoxes = document.querySelectorAll('div.story');
console.log(taskBoxes);